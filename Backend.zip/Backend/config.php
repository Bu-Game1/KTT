<?PHP
    
 
    require  'medoo.php';
    
    try {
        
        
        $database = new medoo([
                              
                              'database_type' => 'mysql',
                              'database_name' => 'KeepTheTrash',
                              'server' => 'localhost',
                              'username' => 'root',
                              'password' => '',
                              'charset' => 'utf8',
                              
                              ]);
        
        echo "Connect Succuss";
        
    } catch( Exception $e ){
        
        echo "Caught exception : <b>".$e->getMessage()."</b><br/>";
        
    }
                          
                          
    
?>