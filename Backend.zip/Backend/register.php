<?PHP
    
 
    include('config.php');
    
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $email = $_POST['email'];
    $hash = md5($pass);
    
    $user = "eve";
    $pass = "eve";
    $email = "qqqq@test.com";
    $hash = md5($pass);
    
    
    $count = $database->count("member", [
                              "username" => $user
                              ]);
    
    if($count > 0){
        
        $datas = $database->select("member","*");
        
        foreach($datas as $data)
        {
            
            $json[] = $data;
        }
        print(json_encode($json));

        
    } else {
        
        $user_data = $database->insert("member", [
                                          "username" => $user,
                                          "password" => $hash,
                                          "email" => $email
                                          ]);
        
        $user_data = $database->insert("score", [
                                       "username" => $user,
                                       "point" => 0
                                       ]);
    }
    
    
    
?>